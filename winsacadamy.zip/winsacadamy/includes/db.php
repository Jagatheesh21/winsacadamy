<?php
$con = mysqli_connect("localhost","root","","wins_academy");
if(!$con)
{
echo "DB not connected";
exit;
}
