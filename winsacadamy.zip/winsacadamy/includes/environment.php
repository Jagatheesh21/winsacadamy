<?php
$company_name = "Wins Acadamy";